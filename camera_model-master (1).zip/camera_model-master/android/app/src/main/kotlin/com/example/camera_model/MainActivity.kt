package com.example.camera_model

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
